# Trabalho-PovRay
